// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


// Custom exception class inheriting from std::exception
class CustomException : public std::exception {
public:
    // Overriding the what() function to provide a custom error message
    const char* what() const noexcept override {
        return "Custom exception occurred";
    }
};

bool do_even_more_custom_application_logic()
{

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    //Throw a standard exception
    throw std::runtime_error("Error: Failed in do_even_more_custom_application_logic()!");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } catch (const std::exception& e) {
        // Catch and handle the exception
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }


    //  Throw a custom exception to test exception handling in main()
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0) {
        throw std::invalid_argument("Don't divide by zero!");
    }
    return (num / den);
}

void do_division() noexcept
{

    float numerator = 10.0f;
    float denominator = 0;

    //test for divide by zero
    try
    {
        //Try to divide the numbers. Prints the numbers if 
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << e.what() << std::endl;
    }
}

int main()
{
    // Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    try
    {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) //catch the custom exception, usually found in do_custom_application_logic() 
    {
        std::cout << "Caught the custom exception: " << e.what() << std::endl;
    }
    catch (const std::exception& e) //catches most other exceptions
    {
        std::cout << "Caught the std::exception: " << e.what() << std::endl;
    }
    catch (...) //catches uncaught exceptions. There should be none.
    {
        std::cout << "Caught the uncaught exception." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu